<div class="container">
    <div class="barrederecherche">
        <div class="controls">
			<div id="search-wrapper">
				<div id="search-box">
					<form action="recherche.php" method="GET">
						<label for="search-field" class="visually-hidden">Rechercher un mot</label>
						<input type="text" id="search-field" name="terme" placeholder="Rechercher un mot..." required>
						<div id="search-button">
							<button type="submit" style="background: none; border: none; cursor: pointer;">
								<i class="fas fa-search"></i>
							</button>
						</div>
					</form>
				</div>
			</div>
        </div>
    </div>
</div>
