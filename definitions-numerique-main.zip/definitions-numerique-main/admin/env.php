<?php 
session_start(); // Démarre la session, si nécessaire

// Définition des informations de connexion à la base de données dans $_ENV
$_ENV = [
  "DB_USERNAME" => "root",  // Nom d'utilisateur de la base de données
  "DB_PASSWORD" => "",      // Mot de passe de la base de données (ici vide)
  "DB_NAME" => "defnumerique", // Nom de la base de données
  "DB_SERVERNAME" => "localhost" // Serveur de la base de données (localhost pour un environnement local)
];

// Créer la connexion à la base de données
$conn = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}
?>
