<?php
// Démarrer la session
session_start();

// Détruire toutes les données de session
session_unset();
session_destroy();

// Rediriger l'utilisateur vers la page de connexion ou l'accueil
header("Location: index.php");  // Remplacez index.php par la page de connexion si nécessaire
exit();
?>
