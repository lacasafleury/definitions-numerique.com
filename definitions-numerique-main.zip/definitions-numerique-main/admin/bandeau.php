<?php
// Démarrer une session


// Inclure le fichier env.php pour la connexion à la base de données
include 'env.php';

$conn = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

// Compter les définitions en attente dans les tables "definition" et "definitionmodif"
$sql_pending_definitions = "SELECT 
    (SELECT COUNT(*) FROM definition WHERE valider = 1) +
    (SELECT COUNT(*) FROM definitionmodif WHERE valider = 2) AS total_pending";

$result = $conn->query($sql_pending_definitions);

$pendingCount = 0;
if ($result && $row = $result->fetch_assoc()) {
    $pendingCount = (int)$row['total_pending'];
}

$conn->close();

// Vérifier si l'utilisateur est connecté (dans cet exemple, on vérifie une variable de session)
if (isset($_SESSION['adminok']) && $_SESSION['adminok'] == 30) {
    $welcomeMessage = "Définition Informatique Admin !";  // Message personnalisé
} else {
    $welcomeMessage = "Bienvenue, invité !";  // Message pour les utilisateurs non connectés
}
?>

<!-- HTML pour le bandeau -->
<div id="welcome-banner" style="background-color: #2C3E50; color: white; text-align: center; padding: 40px; position: fixed; top: 0; left: 0; width: 100%; z-index: 1000; font-size: 40px;">
    <h2 style="margin: 0;">
        <?php echo $welcomeMessage; ?>
    </h2>
    <div>
        <!-- Bouton Ajouter un admin -->
        <a href="ajouter_admin.php" style="margin-right: 20px; padding: 12px 25px; background-color: #BDC3C7; color: black; text-decoration: none; border-radius: 5px; font-size: 18px;">Ajouter un admin</a>
        
        <!-- Bouton Modifier une définition -->
        <a href="def_admin.php" style="margin-right: 20px; padding: 12px 25px; background-color: #BDC3C7; color: black; text-decoration: none ; border-radius: 5px; font-size: 18px;">Modifier une définition</a>
        
        <!-- Bouton pour les définitions en attente avec point rouge -->
        <a href="def_en_attente.php" style="margin-right: 20px; padding: 12px 25px; background-color: #BDC3C7; color: black; text-decoration: none ; border-radius: 5px; font-size: 18px; position: relative;">
            Définition en attente
            <?php if ($pendingCount > 0): ?>
                <span style="position: absolute; top: -10px; right: -10px; background-color: red; color: white; border-radius: 50%; padding: 5px 10px; font-size: 14px;">
                    <?php echo $pendingCount; ?>
                </span>
            <?php endif; ?>
        </a>
        
        <!-- Bouton Liste admin -->
        <a href="log_admin.php" style="margin-right: 20px; padding: 12px 25px; background-color: #BDC3C7; color: black; text-decoration: none ; border-radius: 5px; font-size: 18px;">Liste admin</a>
		
		<!-- Bouton Modifier une définition -->
        <a href="def_sans_categorie.php" style="margin-right: 20px; padding: 12px 25px; background-color: #BDC3C7; color: black; text-decoration: none ; border-radius: 5px; font-size: 18px;">Definition(s) sans catégorie</a>
        
        
        <!-- Bouton Déconnexion positionné en haut à droite -->
        <a href="deconnexion.php" style="position: fixed; top: 10px; right: 10px; padding: 12px 25px; background-color: #dc3545; color: white; text-decoration: none; border-radius: 5px; z-index: 1000; font-size: 18px;">Déconnexion</a>
    </div>
</div>

<!-- Ajouter un petit espace pour que le contenu ne soit pas masqué par le bandeau -->
<div style="margin-top: 80px;"></div>
