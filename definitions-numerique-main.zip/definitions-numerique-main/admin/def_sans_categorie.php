<div> <?php include "bandeau.php" ?> </div>
<h1>Définition(s) sans catégorie<h1/>
<?php
// Inclure le fichier env.php pour la connexion à la base de données
include 'env.php';

$conn = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);


// Requête pour récupérer les définitions sans catégorie
$sql_no_category = "SELECT id, definition_text FROM definition WHERE category_id IS NULL OR category_id = ''";

$result = $conn->query($sql_no_category);

$definitions = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $definitions[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Définitions sans catégorie</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
        }

        .btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Définitions sans catégorie</h1>

    <?php if (!empty($definitions)): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Définition</th>
                    <th>Ajouter à une catégorie</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($definitions as $definition): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($definition['id']); ?></td>
                        <td><?php echo htmlspecialchars($definition['definition_text']); ?></td>
                        <td>
                            <form action="ajouter_categorie.php" method="POST">
                                <input type="hidden" name="definition_id" value="<?php echo $definition['id']; ?>">
                                <select name="category_id" required>
                                    <option value="">-- Sélectionnez une catégorie --</option>
                                    <?php
                                    // Inclure à nouveau env.php pour récupérer les catégories
                                    include 'env.php';
                                    $sql_categories = "SELECT id, category_name FROM categories";
                                    $categories_result = $conn->query($sql_categories);

                                    if ($categories_result && $categories_result->num_rows > 0) {
                                        while ($category = $categories_result->fetch_assoc()) {
                                            echo '<option value="' . htmlspecialchars($category['id']) . '">' . htmlspecialchars($category['category_name']) . '</option>';
                                        }
                                    }
                                    $conn->close();
                                    ?>
                                </select>
                                <button type="submit" class="btn">Ajouter</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Aucune définition sans catégorie n'a été trouvée.</p>
    <?php endif; ?>
</body>
</html>
