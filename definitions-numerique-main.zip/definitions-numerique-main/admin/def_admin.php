<div> <?php include "bandeau.php" ?> </div>
<h1>Liste des définitions</h1>
<?php
include "env.php";  // Connexion déjà établie

// Requête pour récupérer les définitions où valider = 2
$sql = "SELECT * FROM definition WHERE valider = 2";
$result = $conn->query($sql);

// Vérification de l'existence de données
if ($result->num_rows > 0) {
    echo "<h1>Liste des définitions</h1>";
    echo "<ul>";
    // Boucle pour afficher les définitions
    while ($row = $result->fetch_assoc()) {
        echo "<li>";
        echo "<strong>" . htmlspecialchars($row['deftitre']) . ":</strong> " . htmlspecialchars($row['definition']);
        
        // Lien pour modifier
        echo " <a href='mod.php?id=" . $row['defid'] . "' style='left: 10px; padding: 5px 10px; text-decoration: none; border-radius: 3px;'>Modifier</a>";

        // Lien pour supprimer
        echo " <a href='sup.php?id=" . $row['defid'] . "' onclick='return confirm(\"Êtes-vous sûr de vouloir supprimer cette définition ?\");' style='left: 10px; padding: 5px 10px; text-decoration: none; border-radius: 3px;'>Supprimer</a>";
        echo "</li>";
    }
    echo "</ul>";
} else {
    echo "Aucune définition trouvée.";
}

// Fermeture de la connexion
$conn->close();
?>
