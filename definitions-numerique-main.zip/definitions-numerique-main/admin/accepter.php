<?php
include "env.php";

// Connexion à la base de données avec PDO
try {
    $pdo = new PDO("mysql:host={$_ENV['DB_SERVERNAME']};dbname={$_ENV['DB_NAME']};charset=utf8", $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}

// Vérifie si un ID est fourni dans l'URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("ID manquant dans la requête.");
}

$id = (int)$_GET['id'];

// Récupération de la définition existante pour vérifier si elle existe
$query = $pdo->prepare("SELECT * FROM definition WHERE defid = :id");
$query->execute(['id' => $id]);
$definition = $query->fetch(PDO::FETCH_ASSOC);

if (!$definition) {
    die("Définition introuvable.");
}

// Mise à jour de la définition pour la valider
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $updateQuery = $pdo->prepare("UPDATE definition SET valider =2 WHERE defid = :id");
    $updateQuery->execute(['id' => $id]);

    // Redirection ou message de confirmation
    header("Location: def_en_attente.php?success=1");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accepter une définition</title>
</head>
<body>
    <h1>Accepter une définition</h1>

    <p>Êtes-vous sûr de vouloir accepter la proposition de définition suivante ?</p>
    <p><strong>Titre : </strong><?php echo htmlspecialchars($definition['deftitre']); ?></p>
    <p><strong>Description : </strong><?php echo htmlspecialchars($definition['definition']); ?></p>

    <form method="post">
        <button type="submit" style="color: green;">Valider</button>
    </form>

    <p><a href="def_admin.php">Retour à la liste des définitions</a></p>
</body>
</html>
