<?php
include "env.php";

// Connexion à la base de données avec PDO
try {
    $pdo = new PDO("mysql:host={$_ENV['DB_SERVERNAME']};dbname={$_ENV['DB_NAME']};charset=utf8", $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}

// Vérifie si un ID est fourni dans l'URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("ID manquant dans la requête.");
}

$id = (int)$_GET['id'];

// Récupération de la définition existante pour vérifier si elle existe avant de la supprimer
$query = $pdo->prepare("SELECT * FROM definition WHERE defid = :id");
$query->execute(['id' => $id]);
$definition = $query->fetch(PDO::FETCH_ASSOC);

if (!$definition) {
    die("Définition introuvable.");
}

// Suppression de la définition
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Suppression de la définition de la base de données
    $deleteQuery = $pdo->prepare("DELETE FROM definition WHERE defid = :id");
    $deleteQuery->execute(['id' => $id]);

    // Redirection ou message de confirmation
    header("Location: def_admin.php?success=1");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supprimer une définition</title>
</head>
<body>
    <h1>Supprimer une définition</h1>

    <p>Êtes-vous sûr de vouloir supprimer la définition suivante ?</p>
    <p><strong>Titre : </strong><?php echo htmlspecialchars($definition['deftitre']); ?></p>
    <p><strong>Description : </strong><?php echo htmlspecialchars($definition['definition']); ?></p>

    <form method="post">
        <button type="submit" style="color: red;">Supprimer</button>
    </form>

    <p><a href="def_admin.php">Retour à la liste des définitions</a></p>
</body>
</html>
