<div> <?php include "bandeau.php" ?> </div>
<h1>Log admin</h1>
<?php
include "env.php";
// Créer une connexion
$conn = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

// Vérification de la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Requête pour récupérer les définitions
$sql = "SELECT * FROM admin ";
$result = $conn->query($sql);

// Vérification de l'existence de données
if ($result->num_rows > 0) {
    echo "<h1>Log admin</h1>";
    echo "<ul>";
    // Boucle pour afficher les définitions
    while ($row = $result->fetch_assoc()) {
        echo "<li>";
		echo "<br>";
        echo "<strong>" . htmlspecialchars($row['date']) . ":</strong> " . htmlspecialchars($row['mailadmin']);
    }
    echo "</ul>";
} else {
    echo "Aucune définition trouvée.";
}

// Fermeture de la connexion
$conn->close();
?>
