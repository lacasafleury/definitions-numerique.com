<div> <?php include "bandeau.php" ?> </div>
<h1>Liste des définitions</h1>
<?php
include "env.php";

// Connexion à la base de données avec PDO
try {
    $pdo = new PDO("mysql:host={$_ENV['DB_SERVERNAME']};dbname={$_ENV['DB_NAME']};charset=utf8", $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}

// Vérifie si un ID est fourni
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("ID manquant dans la requête.");
}

$id = (int)$_GET['id'];

// Récupération de la définition existante
$query = $pdo->prepare("SELECT * FROM definition WHERE defid = :id");
$query->execute(['id' => $id]);
$definition = $query->fetch(PDO::FETCH_ASSOC);

if (!$definition) {
    die("Définition introuvable.");
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $deftitre = $_POST['deftitre'] ?? '';
    $description = $_POST['definition'] ?? '';

    // Validation des données
    if (empty($deftitre) || empty($description)) {
        $error = "Tous les champs sont obligatoires.";
    } else {
        // Mise à jour de la définition
        $updateQuery = $pdo->prepare("UPDATE definition SET deftitre = :deftitre, definition = :definition WHERE defid = :id");
        $updateQuery->execute([
            'deftitre' => $deftitre,
            'definition' => $description,
            'id' => $id
        ]);

        // Redirection ou message de confirmation
        header("Location: def_admin.php?success=1");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une définition</title>
</head>
<body>
    <h1>Modifier une définition</h1>

    <?php if (isset($error)): ?>
        <p style="color: red;"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>

    <form method="post">
        <label for="deftitre">Titre :</label><br>
        <input type="text" id="deftitre" name="deftitre" value="<?php echo htmlspecialchars($definition['deftitre']); ?>" required><br><br>

        <label for="definition">Description :</label><br>
        <textarea id="definition" name="definition" rows="5" required><?php echo htmlspecialchars($definition['definition']); ?></textarea><br><br>

        <button type="submit">Modifier</button>
    </form>

    <p><a href="def_admin.php">Retour à la liste des définitions</a></p>
</body>
</html>
