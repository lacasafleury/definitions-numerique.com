<html>
<head>
    <meta charset="utf-8">
    <title>Page d'accueil</title>
    <link rel="stylesheet" href="style.css" media="screen" type="text/css" />
</head>
<body>

    <!-- Inclure le bandeau sur cette page -->
    <?php include('bandeau.php'); ?>

    <!-- Contenu de la page -->
    

    <!-- Ton contenu ici -->

</body>
</html>
