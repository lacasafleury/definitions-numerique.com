<div style="background-color: #2C3E50; color: white; text-align: center; width: 100%;z-index: 1000;border-radius: 5px;">
    <h2 style="margin: 0;">bienvenus admin</h2>
<?php

include "env.php";

// Créer une connexion
$conn = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Récupérer les données du formulaire
    $mailadmin = $_POST['mailadmin'];
    $mdpadmin = $_POST['mdpadmin'];

    // Sécuriser les entrées pour éviter les injections SQL
    $mailadmin = $conn->real_escape_string($mailadmin);
    $mdpadmin = $conn->real_escape_string($mdpadmin);

    // Requête pour vérifier si l'email et le mot de passe existent
    $sql = "SELECT * FROM admin WHERE mailadmin = '$mailadmin' AND mdpadmin = '$mdpadmin' LIMIT 1";
	echo "le mots de passe ou l'identifiant est faux";
    $result = $conn->query($sql);


    // Vérifier si un utilisateur correspond à l'email et au mot de passe
    if ($result->num_rows > 0) {
		session_start();
        $_SESSION['adminok'] = 30;  // Sauvegarder l'email dans la session
	    header("Location: index_admin.php");  // Redirection vers la page d'accueil
        exit();
    } else {
        // Si l'utilisateur n'est pas trouvé
        echo "reeseiller";
    }
}
?>

<!-- Formulaire de connexion -->
<form method="POST" action="">
    <label for="email">email:</label>
    <input type="email" name="mailadmin" required><br><br>
    <label for="password">Mot de passe:</label>
    <input type="password" name="mdpadmin" required><br><br>
    <button type="submit">Se connecter</button>
</form>
