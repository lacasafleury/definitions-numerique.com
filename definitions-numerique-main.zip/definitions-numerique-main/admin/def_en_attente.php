<div> <?php include "bandeau.php" ?> </div>
<h1>Liste des définitions en attente</h1>
<?php
include "env.php";
// Créer une connexion
$conn = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

// Vérification de la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Requête pour récupérer les définitions
$sql = "SELECT * FROM definition WHERE valider = 1";
$result = $conn->query($sql);

// Vérification de l'existence de données
if ($result->num_rows > 0) {
    echo "<h1>Liste des définitions en attente</h1>";
    echo "<ul>";
    // Boucle pour afficher les définitions
    while ($row = $result->fetch_assoc()) {
        echo "<li>";
        echo "<strong>" . htmlspecialchars($row['deftitre']) . ":</strong> " . htmlspecialchars($row['definition']);
        
        // Lien pour accepter
        echo " <a href='accepter.php?id=" . $row['defid'] . "' style='left: 10px; padding: 5px 10px; text-decoration: none; border-radius: 3px;'>Accepter</a>";
		        // Lien pour refuser
        echo " <a href='refuser.php?id=" . $row['defid'] . "' style='left: 10px; padding: 5px 10px; text-decoration: none; border-radius: 3px;'>refuser</a>";
        
    }
    echo "</ul>";
} else {
    echo "Aucune définition en attente.";
}

// Fermeture de la connexion
$conn->close();
?>
