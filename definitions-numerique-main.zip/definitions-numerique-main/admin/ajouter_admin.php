html>
<div> <?php include "bandeau.php" ?> </div>
<h1 style="margin: 70;"
<?php
include "env.php";  // Connexion déjà établie

// Vérifier si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Récupérer les données du formulaire
    $mailadmin = $_POST['mailadmin'];
    $mdpadmin = $_POST['mdpadmin'];
    $date = date('Y-m-d H:i:s'); // Date et heure actuelle

    // Hacher le mot de passe avant de l'enregistrer (c'est une bonne pratique)
    $mdp = ($mdpadmin);

    // Préparer la requête SQL pour insérer les données dans la table "admin"
    $sql = "INSERT INTO admin (mailadmin, mdpadmin, adminid, date)
            VALUES (?, ?, ?, ?)";

    // Préparer la requête pour éviter les injections SQL
    if ($stmt = $conn->prepare($sql)) {
        // Lier les paramètres (s, s, i, s) -> string, string, integer, string
        $stmt->bind_param("ssis", $mailadmin, $mdp, $adminid, $date);

        // Exécuter la requête
        if ($stmt->execute()) {
            echo "<h3>Connexion réussie et données enregistrées !</h3>";
            echo "<p>Bienvenue $mailadmin. Vous vous êtes connecté le $date.</p>";
        } else {
            echo "<h3>Erreur d'enregistrement</h3>";
            echo "<p>Une erreur est survenue lors de l'enregistrement des informations.</p>";
        }

        // Fermer la requête préparée
        $stmt->close();
    } else {
        echo "<h3>Erreur SQL</h3>";
        echo "<p>La requête a échoué : " . $conn->error . "</p>";
    }
}

// La connexion est fermée automatiquement dans env.php (si tu as mis une gestion de fermeture).

// Requête pour récupérer les admins
$sql = "SELECT * FROM admin";
$result = $conn->query($sql);

// Vérification de l'existence de données
if ($result->num_rows > 0) {
    echo "<h1>Liste des admins</h1>";
    echo "<ul>";
    // Boucle pour afficher les informations
    while ($row = $result->fetch_assoc()) {
        echo "<li>";
        echo "<strong>" . htmlspecialchars($row['mailadmin']) . ":</strong> " . htmlspecialchars($row['date']);
        
        // Lien pour modifier
        echo " <a href='mod_admin.php?id=" . $row['adminid'] . "' style='left: 10px; padding: 5px 10px; text-decoration: none; border-radius: 3px;'>Modifier</a>";

        // Lien pour supprimer
        echo " <a href='sup.php?id=" . $row['adminid'] . "' onclick='return confirm(\"Êtes-vous sûr de vouloir supprimer cette définition ?\");' style='left: 10px; padding: 5px 10px; text-decoration: none; border-radius: 3px;'>Supprimer</a>";
        echo "</li>";
    }
    echo "</ul>";
} else {
    echo "Aucun admin trouvé.";
}

// La connexion se ferme automatiquement dans env.php (si tu as mis une gestion de fermeture).
?>
</div>
<body>
    <h2>ajouter Admin</h2>
    <form action="ajouter_admin.php" method="post">
        <label for="mailadmin">Email:</label>
        <input type="email" id="mailadmin" name="mailadmin" required><br><br>
        
        <label for="mdpadmin">Mot de passe:</label>
        <input type="password" id="mdpadmin" name="mdpadmin" required><br><br>
        
        <!-- Champ caché pour l'ID -->
        <input type="hidden" name="user_id" value="12345"><br><br> <!-- ID dynamique selon l'utilisateur -->

        <input type="submit" value="ajouter">
    </form>
</body>
</html>
