<?php
session_start(); // Démarrer la session
include "env.php";

// Créer une connexion à la base de données
$conn = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

if (isset($_GET['terme']) && !empty($_GET['terme'])) {
    $terme = htmlspecialchars(trim($_GET['terme'])); // Sécuriser et nettoyer le terme saisi par l'utilisateur

    // Préparation de la requête pour récupérer toutes les définitions
    $stmt = $conn->prepare("SELECT definition , deftitre, defid FROM definition WHERE deftitre LIKE ? AND valider = 2");
    if ($stmt) {
        $terme_like = $terme . '%'; // Utilisation du LIKE pour trouver des mots commençant par le terme
        $stmt->bind_param("s", $terme_like);

        if ($stmt->execute()) {
            $result = $stmt->get_result();

            // Vérifier si des définitions ont été trouvées
            if ($result->num_rows > 0) {
                $definitions = [];
                while ($row = $result->fetch_assoc()) {
                    // Ajouter chaque définition et titre dans le tableau
                    $definitions[] = [
                        'deftitre' => $row['deftitre'],
                        'definition' => $row['definition'],
						'defid' => $row['defid'],

                    ];
                }
                // Stocker les définitions dans la session
                $_SESSION['definitions'] = $definitions;
            } else {
                $_SESSION['definitions'] = [["message" => "Aucune définition trouvée pour le mot '$terme'."]];
            }
        } else {
            $_SESSION['definitions'] = [["message" => "Erreur lors de l'exécution de la requête."]];
        }

        $stmt->close();
    } else {
        $_SESSION['definitions'] = [["message" => "Erreur lors de la préparation de la requête."]];
    }
} else {
    $_SESSION['definitions'] = [["message" => "Veuillez entrer un mot pour la recherche."]];
}

// Fermer la connexion
$conn->close();

// Rediriger vers la page d'affichage des résultats
header('Location: affichelesdefs.php');
exit();
?>
