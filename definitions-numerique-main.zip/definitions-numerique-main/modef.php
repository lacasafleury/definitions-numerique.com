<?php
 include "env.php";

// Create connection
$conn = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}	
//echo "Connected successfully<br>";

// Create connection
$conn2 = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

// Check connection
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}	
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/d76759a8b0.js" crossorigin="anonymous"></script>
</head>

<body>
	<div>
		<div class="bandeaudiv">
			<?php
			include "bandeau.php"
			?>
		</div>
		<div class="logodiv">
			<?php
			include "logo.php"
			?>
		</div>
		<div class="lettresdiv">
			<?php
			include "lettres.php"
			?>
		</div>
		<div class="barrediv">
			<?php
			include "barrederecherche.html"
			?>
		</div>
		<div class="homediv">
			
			  
            <?php


$id = htmlspecialchars($_GET['id']);

    // Afficher les données (ou les traiter comme vous le souhaitez)
    //echo "id : " . $id."<br>" ;
	
$sql = "SELECT * FROM definition WHERE defid=".$id."";
//echo $sql;

//echo "Connected successfully<br>";



/* RequÃªte "Select" retourne un jeu de rÃ©sultats */
if ($result = mysqli_query($conn, $sql)) {
  printf("Select a retournÃ© %d lignes.\n", mysqli_num_rows($result));

   while ($row = $result->fetch_assoc()) {
        $deftitre=$row["deftitre"];
		$deflettre=$row["deflettre"];
		$definition=$row["definition"];
   }
//echo "Deftitre: $deftitre, Deflettre: $deflettre, Definition: $definition <br>";
}
?>


    <form action="modeftraitement.php" method="post">
        <label for="modauteur">Nom :</label>
        <input type="text" id="nom" name="nom" autofocus required ><br><br>
        <label for="modemail">Email :</label>
        <input type="email" id="email" name="email" required ><br><br>
		<label for="modtitre">Titre :</label>
        <input type="text" id="deftitre" name="deftitre" value="<?php echo($deftitre);?>" required ><br><br>
		<label for="modlettre">Première lettre du titre :</label>
        <input type="text" id="deflettre" name="deflettre" value="<?php echo($deflettre);?>" required ><br><br>
		<label for="modefinition">Modification définition :</label>
		<textarea id="definition" name="definition"  required rows="3" cols="80"><?php echo($definition);?> </textarea><br><br>
        <input type="hidden" id="defid" name="defid" value="<?php echo $id;?>"><br><br>
		<input type="submit" value="proposer">
    </form>

</body>
			
			
			
		</div>
		<div class="footerdiv">
			<?php
			include "footer.php"
			?>
		</div>
	</div>

</body>

</html>

         
           
         
</html>


     
