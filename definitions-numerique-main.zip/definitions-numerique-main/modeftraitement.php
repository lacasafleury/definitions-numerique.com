<?php
 include "env.php";

// Create connection
$conn = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}	
//echo "Connected successfully<br>";

// Create connection
$conn2 = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

// Check connection
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}	


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données du formulaire
    $modemail = htmlspecialchars($_POST['email']);
	$modefinition = htmlspecialchars($_POST['definition']);
	$modlettre = htmlspecialchars($_POST['deflettre']);
	$modtitre = htmlspecialchars($_POST['deftitre']);
	$modauteur = htmlspecialchars($_POST['nom']);
	$idorigine = htmlspecialchars($_POST['defid']);
	
    
    // Afficher les données (ou les traiter comme vous le souhaitez)
    echo "Email : " . $modemail . "<br>";
	echo "Modefinition : " . $modefinition . "<br>";
	echo "Modtitre : " . $modtitre . "<br>";
	echo "Modlettre : " . $modlettre . "<br>";
	echo "Auteur : " . $modauteur . "<br>";
   }

// Création de la date
$modate = date('Y-m-d H:i:s');

// Préparation de la requête SQL
$sql = "INSERT INTO definitionmodif (idorigine, modlettre, modtitre, modefinition, modauteur, modate, valider, modemail) 
VALUES ('$idorigine','$modlettre', '$modtitre', '$modefinition', '$modauteur', '$modate', 1,  '$modemail' )";

// Exécution de la requête
//echo $sql; // Affiche la requête pour vérifier sa validité (facultatif)



//echo $sql;
if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();

header('Location: thanks.php');


?>