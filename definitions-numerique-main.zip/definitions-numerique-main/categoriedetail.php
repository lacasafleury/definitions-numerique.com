<?php
	include "env.php"
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <link rel="stylesheet" href="style.css" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/d76759a8b0.js" crossorigin="anonymous"></script>
</head>

<body>
	<div class="global">
		<div class="bandeaudiv">
			<?php
			include "bandeau.php"
			?>
		</div>
		<div class="logodiv">
			<?php
			include "logo.php"
			?>
		</div>
		<div class="lettresdiv">
			<?php
			include "lettres.php"
			?>
		</div>
		<div class="barrediv">
			<?php
			include "barrederecheche.php"
			?>
		</div>
		<div class="homediv">
			
		  <div class="container">
	    <div class="home">
			<div class="gauche">

		
		<?php
// Envoyer l'encodage UTF-8 dans les en-têtes HTTP
header('Content-Type: text/html; charset=UTF-8');

// Exemple d'affichage
?>
<?php
 

// Create connection
$conn = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}	
//echo "Connected successfully<br>";

// Create connection
$conn2 = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

// Check connection
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}	
//echo "Connected successfully<br>";

/* RequÃªte "Select" retourne un jeu de rÃ©sultats */
if ($result = mysqli_query($conn, "SELECT * from categorie")) 
{
//   printf("Select a retournÃ© %d lignes.\n", mysqli_num_rows($result));
   
    while ($row = $result->fetch_assoc()) 
	{
        printf ("<h2><u><a href='categoriedetail.php?catid=%s'>%s</a></u></h2>", $row['catid'], $row['catnom']);
		// comptage du nombre de def par categorie
		$catid = intval($row['catid']);
		$sql2="SELECT COUNT(*) as total FROM lien WHERE catid=" . $catid;
		//echo $sql2;
		if ($result2 = mysqli_query($conn2,$sql2 )) 
		{
		    //printf("Select a retournÃ© %d lignes.\n", mysqli_num_rows($result2));
			while ($row2 = $result2->fetch_assoc()) 
			{
				printf ("<br>&nbsp;&nbsp;&nbsp;&nbsp;( %s résultats)<br> ", $row2['total']);
				
			}
		} 
		else 
		{
		   //printf("erreur");
		}
	}
}	
$conn->close();
?>
			</div>
			
			
			<div class="droite">
				<?php
	
				$id = htmlspecialchars($_GET['catid']);

				// Create connection
				$conn = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

				// Check connection
				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				}	

				//echo "Connected successfully<br>";

				/* RequÃªte "Select" retourne un jeu de rÃ©sultats */
				$SQL4 = "SELECT catnom FROM categorie INNER JOIN lien ON lien.catid=categorie.catid WHERE lien.catid = $id";
				//echo $SLQ4;
				if ($result = mysqli_query($conn, $SQL4));
				{ 
				 $row = $result->fetch_assoc();
					
					// Vérifie si une ligne a été retournée
					if ($row) {
						printf ("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp<h2><u><a>%s</a></u></h2><br><br>", $row['catnom']);

					}
				}
					
				/* RequÃªte "Select" retourne un jeu de rÃ©sultats */
				$SQL3 = "SELECT definition,deftitre FROM definition INNER JOIN lien ON lien.defid=definition.defid WHERE lien.catid = $id";
				//echo $SLQ3;
				if ($result = mysqli_query($conn, $SQL3));
				{
					//printf("Select a retournÃ© %d lignes.\n", mysqli_num_rows($result));
					while ($row = $result->fetch_assoc()) 
					{
						printf('<h2><u><a href="affichedef.php?defid=' . urlencode($row['defid']) . '" class="link">' . htmlspecialchars($row['deftitre']) . '</a></u></h2>');
					}
				}	

				$conn->close();
				?>
			</div>
		 </div>
    </div>
		
		</div>
		<div class="footerdiv">
			<?php
			include "footer.php"
			?>
		</div>
	</div>

</body>

</html>
