    <div class="container">
	    <div class="home">
			<div class="gauche">

		
		<?php
		include "env.php"


// Exemple d'affichage
?>
<?php

// Create connection
$conn = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}	
//echo "Connected successfully<br>";

// Create connection
$conn2 = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

// Check connection
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}	
//echo "Connected successfully<br>";

/* RequÃªte "Select" retourne un jeu de rÃ©sultats */
if ($result = mysqli_query($conn, "SELECT * from categorie")) 
{
//   printf("Select a retournÃ© %d lignes.\n", mysqli_num_rows($result));
   
    while ($row = $result->fetch_assoc()) 
	{
        printf ("<h2><u><a href='categoriedetail.php?catid=%s'>%s</a></u></h2>", $row['catid'], $row['catnom']);
		// comptage du nombre de def par categorie
		$catid = intval($row['catid']);
		$sql2="SELECT COUNT(*) as total FROM lien WHERE catid=" . $catid;
		//echo $sql2;
		if ($result2 = mysqli_query($conn2,$sql2 )) 
		{
		    //printf("Select a retournÃ© %d lignes.\n", mysqli_num_rows($result2));
			while ($row2 = $result2->fetch_assoc()) 
			{
				printf ("<br>&nbsp;&nbsp;&nbsp;&nbsp;( %s résultats)<br> ", $row2['total']);
				
			}
		} 
		else 
		{
		   //printf("erreur");
		}
	}
}	
$conn->close();
$conn2->close();

?>
			</div>
			
			
			<div class="droite">
				<h2><u> Définition la plus populaire: </u></h2>
				<?php
				// Create connection
$conn4 = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

// Check connection
if ($conn4->connect_error) {
    die("Connection failed: " . $conn4->connect_error);
}	
//echo "Connected successfully<br>";
				if ($result10 = mysqli_query($conn4, "SELECT deftitre, definition from definition ORDER BY nb_vue DESC LIMIT 1")) 
{
//   printf("Select a retournÃ© %d lignes.\n", mysqli_num_rows($result10));
   
    while ($row10 = $result10->fetch_assoc()) 
	{
        printf("<h2><u><a>%s</a></u></h2><p>%s</p>", $row10['deftitre'], $row10['definition']);

	}
}
$conn4->close();
?>				
			</div>
		 </div>
    </div>
