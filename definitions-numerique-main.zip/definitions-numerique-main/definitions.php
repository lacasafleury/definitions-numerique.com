<?php
include "env.php";  // Inclure les variables d'environnement

// Démarrer la session pour accéder aux données stockées dans la session
session_start();
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <link rel="stylesheet" href="style.css" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/d76759a8b0.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="bandeaudiv" type="video/mp4">
        <?php include "bandeau.php"; ?>
    </div>
    <div class="lettresdiv">
        <?php include "lettres.php"; ?>
    </div>
    <div class="barrediv">
        <?php include "barrederecherche.php"; ?>
    </div>
    <div class="homediv">
        <div class="container">
            <div class="home">
                <div class="controls">
                    <?php
                    // Connexion à la base de données avec mysqli
                    $conn = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

                    // Vérifier la connexion
                    if ($conn->connect_error) {
                        die("Échec de la connexion : " . $conn->connect_error);
                    }

                    // Préparer la requête SQL pour récupérer toutes les définitions
                    $sql = "SELECT defid, deftitre, definition FROM definition";
                    $stmt = $conn->prepare($sql);

                    // Vérifier si la préparation de la requête a échoué
                    if (!$stmt) {
                        die("Erreur dans la préparation de la requête : " . $conn->error);
                    }

                    // Exécuter la requête
                    $stmt->execute();  

                    // Récupérer le résultat
                    $result = $stmt->get_result();

                    // Vérifier s'il y a des résultats
                    if ($result->num_rows > 0) {
                        // Parcourir toutes les définitions
                        while ($row = $result->fetch_assoc()) {
                            echo '<div class="definition-box">';
                            echo '<h2><u><a href="affichedef.php?defid=' . urlencode($row['defid']) . '" class="link">' . htmlspecialchars($row['deftitre']) . '</a></u></h2>';

                            echo '</div>';
                        }
                    } else {
                        echo "<p>Aucune définition trouvée dans la base de données.</p>";
                    }

                    // Fermer la requête préparée
                    $stmt->close();

                    // Fermer la connexion à la base de données
                    $conn->close();
                    ?>
                </div>
            </div>
        </div>
    </div>
    <div class="footerdiv">
        <?php include "footer.php"; ?>
    </div>
</body>

</html>
