<?php
	include "env.php"
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <link rel="stylesheet" href="style.css" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/d76759a8b0.js" crossorigin="anonymous"></script>
</head>

<body>
		<div class="bandeaudiv" type="video/mp4">
			<?php
			include "bandeau.php"
			?>
		</div>
		<div class="lettresdiv">
			<?php
			include "lettres.php"
			?>
		</div>
		<div class="barrediv">
			<?php
			include "barrederecherche.php"
			?>
		</div>
		<div class="homediv">
		<div class="container">
    <div class="home">
        <div class="controls">
		
		<table>
    <tr>
        <td>LOGIN</td>
        <td>DATE CONNECTION</td>
    </tr>


</table>

    <form action="newdeftraitement.php" method="post">
        <label for="nom">Nom :</label>
        <input type="text" id="nom" name="nom" required ><br><br>
        <label for="email">Email :</label>
        <input type="email" id="email" name="email" required ><br><br>
		<label for="deftitre">Titre :</label>
        <input type="text" id="deftitre" name="deftitre" required ><br><br>
		<label for="deflettre">Première lettre du titre :</label>
        <input type="text" id="deflettre" name="deflettre" required ><br><br>
		<label for="nvldef">Nouvelle définition :</label>
		<textarea id="nvldef" name="nvldef" required >
</textarea><br><br>
		<input type="submit" value="proposer">

    </form>
		</div>
			</div>
				</div>
		</div>
		<div class="footerdiv">
			<?php
			include "footer.php"
			?>
		</div>

</body>

</html>
