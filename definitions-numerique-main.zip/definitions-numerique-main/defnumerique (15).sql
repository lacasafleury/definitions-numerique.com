-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mar. 07 jan. 2025 à 15:33
-- Version du serveur :  5.7.17
-- Version de PHP :  7.1.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `defnumerique`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `adminid` int(10) NOT NULL,
  `mailadmin` varchar(100) NOT NULL,
  `mdpadmin` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`adminid`, `mailadmin`, `mdpadmin`, `date`) VALUES
(2, 'test@gmail.com', '1234', '2024-12-16 08:29:48');

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `catid` int(10) NOT NULL,
  `catnom` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`catid`, `catnom`) VALUES
(1, 'Programmation et developpement'),
(2, 'Donnees et IA'),
(3, 'Securite et reseaux'),
(4, 'Web et technologies associees'),
(5, 'Infrastructure et services'),
(6, 'Interfaces utilisateur');

-- --------------------------------------------------------

--
-- Structure de la table `definition`
--

CREATE TABLE `definition` (
  `defid` int(11) NOT NULL,
  `deflettre` varchar(1) CHARACTER SET latin1 NOT NULL,
  `deftitre` varchar(100) CHARACTER SET latin1 NOT NULL,
  `definition` varchar(1000) CHARACTER SET latin1 NOT NULL,
  `defauteur` varchar(100) CHARACTER SET latin1 NOT NULL,
  `defdate` date NOT NULL,
  `valider` int(1) NOT NULL DEFAULT '2',
  `defemail` varchar(100) NOT NULL,
  `nb_vue` int(100) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `definition`
--

INSERT INTO `definition` (`defid`, `deflettre`, `deftitre`, `definition`, `defauteur`, `defdate`, `valider`, `defemail`, `nb_vue`) VALUES
(1, 'A', 'Algorithmique', 'Ensemble d\'instructions ordonnees permettant de resoudre un probleme ou d\'accomplir une tache de maniere automatique.', '', '2024-11-04', 1, '', 0),
(2, 'A', 'API (application programming interface)', 'Interface permettant a differentes applications de communiquer entre elles, en exposant des fonctionnalites pour simplifier les interactions.', '', '2024-11-04', 1, '', 0),
(3, 'A', 'Application', 'Logiciel ou programme destine a realiser une tache ou un ensemble de taches specifiques pour l\'utilisateur.\r\n', '', '2024-11-04', 2, '', 0),
(4, 'B', 'Base de donnees', 'Ensemble organise de donnees structurees, stockees et accessibles electroniquement, souvent gerees par un systeme de gestion de base de donnees (SGBD).\r\n', '', '2024-11-04', 2, '', 0),
(5, 'B', 'Big Data', 'Ensemble massif de donnees dont le volume, la vitesse, et la variete necessitent des technologies et des outils specifiques pour etre stockes, analyses et exploites.\r\n', '', '2024-11-04', 2, '', 0),
(6, 'B', 'Bug', 'Defaut ou erreur dans un programme informatique, provoquant un comportement inattendu ou incorrect.', '', '2024-11-04', 2, '', 0),
(7, 'C', 'Cloud Computing', 'Utilisation de serveurs distants via Internet pour stocker, gerer et traiter des donnees, plutot que d\'utiliser des serveurs ou des ordinateurs locaux.', '', '2024-11-04', 2, '', 0),
(8, 'C', 'Code Source', 'Ensemble des instructions ecrites dans un langage de programmation qui definit le fonctionnement d\'un programme.', '', '2024-11-04', 2, '', 0),
(9, 'C', 'Cybersecurite', 'Ensemble de pratiques et de technologies destinees a proteger les systemes informatiques et les donnees contre les cyberattaques.', '', '2024-11-04', 2, '', 0),
(10, 'D', 'Data Science', 'Discipline qui utilise des techniques statistiques, de programmation et d\'apprentissage automatique pour analyser des donnees et en tirer des informations utiles.', '', '2024-11-04', 2, '', 0),
(11, 'D', 'DDoS (Distributed Denial of Service)', 'Attaque visant a rendre un service indisponible en surchargeant le serveur avec un nombre massif de requetes.', '', '2024-11-04', 2, '', 0),
(12, 'D', 'Debogage', 'Processus de recherche et de correction des erreurs dans un programme informatique', '', '2024-11-04', 2, '', 0),
(13, 'E', 'Encapsulation', 'Principe de programmation orientee objet qui consiste a cacher les details internes d\'un objet et a exposer seulement ce qui est necessaire pour son utilisation.', '', '2024-11-04', 2, '', 0),
(14, 'E', 'Extranet', 'Reseau securise et prive etendu, permettant un acces externe limite aux partenaires commerciaux ou clients.', '', '2024-11-04', 2, '', 0),
(15, 'F', 'Firewall (Pare-feu)', 'Systeme de securite reseau qui controle le trafic entrant et sortant en fonction de regles de securite predefinies.', '', '2024-11-04', 2, '', 0),
(16, 'F', 'Framework', 'Structure de code reutilisable qui sert de base pour le developpement d\'applications, simplifiant ainsi certaines taches repetitives.', '', '2024-11-04', 2, '', 0),
(17, 'G', 'Git', 'Logiciel de gestion de versions permettant de suivre les modifications dans le code source au fil du temps et de collaborer avec d\'autres developpeurs.', '', '2024-11-04', 2, '', 0),
(18, 'G', 'GUI (Graphical User Interface)', 'Interface graphique permettant aux utilisateurs d\'interagir avec un logiciel via des elements visuels comme des boutons, des icones, et des fenetres.', '', '2024-11-04', 2, '', 0),
(19, 'H', 'Hebergement Web', 'Service permettant de stocker et de rendre accessible un site web ou une application sur Internet.', '', '2024-11-04', 2, '', 0),
(20, 'H', 'HTML (HyperText Markup Language)', 'Langage de balisage utilise pour structurer et presenter le contenu des pages web.\r\n', '', '2024-11-04', 2, '', 0),
(21, 'I', 'IA (Intelligence Artificielle)', 'Simulation de processus d\'intelligence humaine par des machines, en particulier par des systemes informatiques.', '', '2024-11-04', 2, '', 0),
(22, 'I', 'Internet des Objets (IoT)', 'Reseau d\'objets physiques connectes a Internet, capables de collecter et d\'echanger des donnees.', '', '2024-11-04', 2, '', 0),
(23, 'J', 'JavaScript', 'Langage de programmation principalement utilise pour le developpement web et pour rendre les pages interactives.', '', '2024-11-04', 2, '', 0),
(24, 'J', 'JSON (JavaScript Object Notation)', 'Format leger de donnees structure, facile a lire et a ecrire, souvent utilise pour echanger des donnees entre serveurs et clients.', '', '2024-11-04', 2, '', 0),
(25, 'L', 'Langage de programmation', 'Langage utilise pour ecrire les instructions permettant de creer des logiciels ou des scripts.', '', '2024-11-04', 2, '', 0),
(26, 'L', 'Logiciel libre', 'Logiciel dont le code source est accessible et peut etre modifie, distribue et utilise gratuitement.', '', '2024-11-04', 2, '', 0),
(27, 'M', 'Machine Learning (Apprentissage Automatique)', 'Branche de l\'IA permettant aux machines d\'apprendre et d\'ameliorer leurs performances grace a des donnees, sans programmation explicite pour chaque tache.', '', '2024-11-04', 2, '', 0),
(28, 'M', 'Malware', 'Logiciel malveillant concu pour nuire ou exploiter un systeme informatique.', '', '2024-11-04', 2, '', 0),
(29, 'N', 'Network (Reseau)', 'Ensemble d\'ordinateurs ou de dispositifs interconnectes permettant l\'echange d\'informations et de ressources.', '', '2024-11-04', 2, '', 0),
(30, 'N', 'Noeud', 'Dispositif connecte dans un reseau, pouvant etre un ordinateur, un routeur ou un autre peripherique.', '', '2024-11-04', 2, '', 0),
(31, 'O', 'Open Source', 'Logiciel dont le code source est disponible publiquement et peut etre modifie et partage librement.', '', '2024-11-04', 2, '', 0),
(32, 'O', 'Optimisation', 'Processus d\'amelioration des performances d\'un programme, d\'un algorithme ou d\'un systeme informatique.', '', '2024-11-04', 2, '', 0),
(33, 'P', 'Programmation Oriente Objet (POO)', 'Paradigme de programmation base sur la creation et l\'interaction d\'objets, utilises pour modeliser des donnees et des comportements.', '', '2024-11-04', 2, '', 0),
(34, 'P', 'Protocole', 'Ensemble de regles permettant la communication entre des dispositifs ou des systemes informatiques (ex. : HTTP, FTP).', '', '2024-11-04', 2, '', 0),
(35, 'Q', 'QR Code', 'Type de code-barres en deux dimensions qui peut stocker des informations et etre scanne par des dispositifs comme les smartphones', '', '2024-11-04', 2, '', 0),
(36, 'R', 'Reseau Prive Virtuel (VPN)', 'Service de securite qui permet de creer une connexion Internet cryptee et securisee a travers un reseau public', '', '2024-11-04', 2, '', 0),
(37, 'R', 'Routeur', 'Dispositif reseau qui transmet des paquets de donnees entre differents reseaux informatiques.', '', '2024-11-04', 2, '', 0),
(38, 'S', 'Serveur', 'Ordinateur ou programme qui fournit des services, des donnees ou des ressources a d\'autres ordinateurs, appeles clients.', '', '2024-11-04', 2, '', 0),
(39, 'S', 'Securite Informatique', 'Ensemble de mesures visant a proteger les informations et les systemes contre les menaces numeriques.', '', '2024-11-04', 2, '', 0),
(40, 'T', 'Tableau de Bord (Dashboard)', 'Interface visuelle qui regroupe et presente des donnees cles sous forme de graphiques, facilitant l\'analyse et la prise de decision.', '', '2024-11-04', 2, '', 0),
(41, 'T', 'TCP/IP (Transmission Control Protocol/Internet Protocol)', 'Ensemble de protocoles fondamentaux permettant la transmission de donnees sur Internet', '', '2024-11-04', 2, '', 0),
(42, 'U', 'UI (User Interface)', 'Interface utilisateur permettant aux individus d\'interagir avec un logiciel ou un dispositif electronique', '', '2024-11-04', 2, '', 0),
(43, 'U', 'URL (Uniform Resource Locator)', 'Adresse unique permettant d\'acceder a une ressource specifique sur Internet.', '', '2024-11-04', 2, '', 0),
(44, 'V', 'Virtualisation', 'Technique permettant de creer des versions virtuelles de ressources materielle, comme des serveurs, des reseaux ou des systemes de stockage.', '', '2024-11-04', 2, '', 0),
(45, 'V', 'Virus', 'Programme malveillant qui se reproduit et infecte d\'autres programmes ou fichiers.', '', '2024-11-04', 2, '', 0),
(46, 'W', 'Web', 'Ensemble de documents interconnectes accessibles sur Internet via des navigateurs', '', '2024-11-04', 2, '', 0),
(47, 'W', 'Webinaire', 'Seminaire en ligne permettant aux participants de se rencontrer et d\'interagir a distance.', '', '2024-11-04', 2, '', 0),
(50, 'Z', 'ZIP', 'Format de fichier compresse qui permet de reduire la taille des fichiers pour faciliter leur stockage ou leur transmission.', '', '2024-11-04', 2, '', 0),
(48, 'X', 'XHTML (Extensible HyperText Markup Language)', 'Une version plus stricte de HTML qui combine les caracteristiques de HTML et XML pour structurer des documents web tout en assurant leur conformite a la syntaxe XML.', '', '2024-11-25', 2, '', 0),
(49, 'Y', 'Yotta', 'Un prefixe du Systeme international d\'unites (SI) representant 10^24, souvent utilise pour mesurer des quantites astronomiques de donnees ou d\'autres grandeurs.', '', '2024-11-25', 2, '', 0),
(53, 'Z', 'YKUFKY', 'LIUTF', '', '2024-12-10', 2, '', 0),
(55, 'K', 'KAKA', 'KAKABOUDIN', '', '2025-01-07', 2, '', 0);

-- --------------------------------------------------------

--
-- Structure de la table `definitionmodif`
--

CREATE TABLE `definitionmodif` (
  `modid` int(11) NOT NULL,
  `modlettre` varchar(1) NOT NULL,
  `modtitre` varchar(100) NOT NULL,
  `modefinition` varchar(1000) NOT NULL,
  `modauteur` varchar(100) NOT NULL,
  `modate` date NOT NULL,
  `valider` int(1) NOT NULL,
  `modemail` varchar(150) NOT NULL,
  `idorigine` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `definitionmodif`
--

INSERT INTO `definitionmodif` (`modid`, `modlettre`, `modtitre`, `modefinition`, `modauteur`, `modate`, `valider`, `modemail`, `idorigine`) VALUES
(1, 'A', 'Automatique', 'Ensemble des sciences et des techniques consacrees aux dispositifs qui fonctionnent sans intervention du travail humain.', 'aaa', '2024-12-17', 1, 'a@a.aa', 66);

-- --------------------------------------------------------

--
-- Structure de la table `lien`
--

CREATE TABLE `lien` (
  `lienid` int(10) NOT NULL,
  `defid` int(10) NOT NULL,
  `catid` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `lien`
--

INSERT INTO `lien` (`lienid`, `defid`, `catid`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 10, 1),
(5, 18, 1),
(6, 27, 1),
(7, 19, 1),
(8, 11, 2),
(9, 30, 2),
(10, 17, 2),
(11, 38, 2),
(12, 4, 2),
(13, 5, 2),
(14, 7, 3),
(15, 8, 3),
(16, 12, 4),
(17, 13, 4),
(18, 44, 5),
(19, 45, 5),
(20, 28, 6),
(21, 29, 6);

-- --------------------------------------------------------

--
-- Structure de la table `logs`
--

CREATE TABLE `logs` (
  `logs` int(11) NOT NULL,
  `statut` int(11) NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `evenement` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `adminid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminid`);

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`catid`);

--
-- Index pour la table `definition`
--
ALTER TABLE `definition`
  ADD PRIMARY KEY (`defid`);

--
-- Index pour la table `definitionmodif`
--
ALTER TABLE `definitionmodif`
  ADD PRIMARY KEY (`modid`);

--
-- Index pour la table `lien`
--
ALTER TABLE `lien`
  ADD PRIMARY KEY (`lienid`);

--
-- Index pour la table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`logs`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `catid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `definition`
--
ALTER TABLE `definition`
  MODIFY `defid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT pour la table `definitionmodif`
--
ALTER TABLE `definitionmodif`
  MODIFY `modid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `lien`
--
ALTER TABLE `lien`
  MODIFY `lienid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT pour la table `logs`
--
ALTER TABLE `logs`
  MODIFY `logs` int(11) NOT NULL AUTO_INCREMENT;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
