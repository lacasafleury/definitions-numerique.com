<div class="container">
    <div class="rectangle-top">

        <!-- Boutons principaux -->
        <div class="bouton-container">
            <a href="newdef.php" class="bouton bouton-primary">Proposer une nouvelle définition</a>
            <a href="definitions.php" class="bouton bouton-primary">Définitions</a>
            <a href="categories.php" class="bouton bouton-primary">Catégories</a>
            <a href="populaires.php" class="bouton bouton-primary">Les plus populaires</a>
        </div>
    </div>
</div>
