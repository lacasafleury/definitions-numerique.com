<div class="container">
    <div class="lettresdiv">
        <div class="controls">



            <?php
				$conn = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				}
                if ($result = mysqli_query($conn, "SELECT deflettre from definition GROUP BY deflettre")) {
					echo "<ul class='lettre-list'>";
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td><a href='defparlettre.php?id=" . $row['deflettre'] . "' class='lettre'>" . $row['deflettre'] . "</a></td></tr>";
                    }

                    mysqli_free_result($result);
                }

                // Close connection
                $conn->close();
            ?>
  
        </div>

       
    </div>
</div>




