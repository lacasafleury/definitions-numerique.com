<?php
include "env.php";  // Inclure les variables d'environnement

// Démarrer la session pour accéder aux données stockées dans la session
session_start();


?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <link rel="stylesheet" href="style.css" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/d76759a8b0.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="bandeaudiv" type="video/mp4">
        <?php include "bandeau.php"; ?>
    </div>
    <div class="lettresdiv">
        <?php include "lettres.php"; ?>
    </div>
    <div class="barrediv">
        <?php include "barrederecherche.php"; ?>
    </div>
    <div class="homediv">
        <div class="container">
            <div class="home">
                <div class="controls">
                    <?php
                    // Connexion à la base de données avec mysqli
                    $conn = new mysqli($_ENV['DB_SERVERNAME'], $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD'], $_ENV['DB_NAME']);

                    // Vérifier la connexion
                    if ($conn->connect_error) {
                        die("Échec de la connexion : " . $conn->connect_error);
                    }

                    // Vérifier si l'ID du mot est passé dans l'URL
                    if (isset($_GET['defid'])) {
                        $motId = $_GET['defid'];  // Récupérer l'ID du mot depuis l'URL

                        // Préparer la requête SQL avec mysqli
                        $stmt = $conn->prepare("SELECT defid, deftitre, definition FROM definition WHERE defid = ?");
                        
                        // Vérifier si la préparation de la requête a échoué
                        if ($stmt === false) {
                            // Afficher l'erreur SQL pour le débogage
                            die('Erreur dans la préparation de la requête : ' . $conn->error);
                        }

                        // Lier l'ID à la requête
                        $stmt->bind_param("i", $motId); // "i" pour entier

                        // Exécuter la requête
                        $stmt->execute();  

                        // Récupérer le résultat
                        $result = $stmt->get_result();
                        $definition = $result->fetch_assoc();

                        // Vérifier si une définition a été trouvée
                        if ($definition) {
                            echo '<div class="definition-box">';
                            echo "<h2><u>" . htmlspecialchars($definition['deftitre']) . "</u></h2>";  // Titre de la définition
                            echo "<p>" . nl2br(htmlspecialchars($definition['definition'])) . "</p>"; // Contenu de la définition
                            echo '</div>';
							echo '<button class="btn-modifier" onclick="window.location.href=\'modef.php?defid=' . urlencode($definition['defid']) . '\'">Modifier la définition</button>'; // Bouton de modification

                        } else {
                            echo "<p>La définition demandée n'a pas été trouvée dans la base de données.</p>";
                        }

                        // Fermer la requête préparée
                        $stmt->close();
                    } else {
                        echo "<p>Veuillez spécifier un mot dans l'URL.</p>";
                    }

                    // Fermer la connexion à la base de données
                    $conn->close();
                    ?>
                </div>
            </div>
        </div>
    </div>
    <div class="footerdiv">
        <?php include "footer.php"; ?>
    </div>
</body>

</html>
