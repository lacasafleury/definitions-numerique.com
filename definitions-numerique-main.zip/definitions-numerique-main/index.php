<?php
	include "env.php"
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <link rel="stylesheet" href="style.css" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/d76759a8b0.js" crossorigin="anonymous"></script>
</head>

<body>
		<div class="bandeaudiv" type="video/mp4">
			<?php
			include "bandeau.php"
			?>
		</div>
		<div class="lettresdiv">
			<?php
			include "lettres.php"
			?>
		</div>
		<div class="barredivmain">
			<?php
			include "barrederecherche.php"
			?>
		</div>
		<div class="homediv">
			<?php
			include "home.php"
			?>
		</div>
		<div class="footerdiv">
			<?php
			include "footer.php"
			?>
		</div>

</body>

</html>
