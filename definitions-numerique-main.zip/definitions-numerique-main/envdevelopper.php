<?php 
session_start();
$_ENV = [
  "DB_USERNAME" => "defnsi",
  "DB_PASSWORD" => "_Y)h5UY{PNXq",
  "DB_NAME" => "defnumerique",
  "DB_SERVERNAME" => "sql-server.k8s-aic2hmkb	",
  "STUDENTS_PER_PAGE" => 25,
  "WEBSOCKET_MASTER" => "SPOJD!@$*(USdbhjaldfwjr1@#!@)(#_!///!@#M.M11DSA'KD__123@!#@NSDNdnsDNMN]1]1@}!}@}!@}!@}}!@..,D1232-0421=-2193-89DYHSOQGVCXCDS;][]\[\][\][DMI12",
  "DKIM" => false
];
?>
