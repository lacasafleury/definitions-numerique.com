<?php
include "env.php";
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <link rel="stylesheet" href="style.css" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/d76759a8b0.js" crossorigin="anonymous"></script>
</head>
<?php 
session_start();
?>
<body>
    <div class="bandeaudiv" type="video/mp4">
        <?php include "bandeau.php"; ?>
    </div>
    <div class="lettresdiv">
        <?php include "lettres.php"; ?>
    </div>
    <div class="barrediv">
        <?php include "barrederecherche.php"; ?>
    </div>
    <div class="homediv">
        <div class="container">
            <div class="home">
                <div class="controls">
                    <?php
                    // Vérifier si des définitions sont disponibles dans la session
                    if (isset($_SESSION['definitions']) && !empty($_SESSION['definitions'])) {
                        // Parcourir le tableau des définitions
                        foreach ($_SESSION['definitions'] as $definition) {
							
                            echo '<div class="definition-box">';
                            echo '<h2><u><a href="affichedef.php?defid=' . urlencode($definition["defid"]) . '" class="link">' . htmlspecialchars($definition["deftitre"]) . '</a></u></h2>';
                            echo '<br>'; // Saut de ligne entre les définitions
                            echo '</div>';
                        }
                    } else {
                        echo "<p>Aucune définition trouvée.</p>"; // Message lorsque aucune définition n'est disponible
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
    <div class="footerdiv">
        <?php include "footer.php"; ?>
    </div>
</body>

</html>
